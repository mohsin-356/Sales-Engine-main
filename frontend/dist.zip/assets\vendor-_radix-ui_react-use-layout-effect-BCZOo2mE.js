import{r as o}from"./vendor-react-CAfttCsO.js";var a=globalThis!=null&&globalThis.document?o.useLayoutEffect:()=>{};export{a as u};
