var i="Invariant failed";function a(n,r){throw new Error(i)}export{a as i};
