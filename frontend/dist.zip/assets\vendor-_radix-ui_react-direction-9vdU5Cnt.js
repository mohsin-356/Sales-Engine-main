import{r as t}from"./vendor-react-CAfttCsO.js";var e=t.createContext(void 0);function i(r){const o=t.useContext(e);return r||o||"ltr"}export{i as u};
