var e=function(){if(typeof __webpack_nonce__!="undefined")return __webpack_nonce__};export{e as g};
