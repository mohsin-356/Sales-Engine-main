function h(f,c,{checkForDefaultPrevented:p=!0}={}){return function(s){if(f==null||f(s),p===!1||!s.defaultPrevented)return c==null?void 0:c(s)}}export{h as c};
